--DML-----------------------------------------------------------------------------------------------------
-- JUEGO DE DATOS DE PRUEBA
-----------------------------------------------------------------------------------------------------

-- Choferes
INSERT INTO Chofer VALUES (1, 'Carlos', 'Gomez', '45678912', '1985-04-12', 'LIC1234');
INSERT INTO Chofer VALUES (2, 'Laura', 'Perez', '51239874', '1990-09-20', 'LIC5678');
INSERT INTO Chofer VALUES (3, 'Mart�n', 'Rodr�guez', '47851236', '1988-01-15', 'LIC9012');
INSERT INTO Chofer VALUES (4, 'Sof�a', 'L�pez', '49231478', '1992-07-02', 'LIC3456');
INSERT INTO Chofer VALUES (5, 'Javier', 'Fern�ndez', '50321789', '1983-11-28', 'LIC7788');
INSERT INTO Chofer VALUES (6, 'Mariana', 'Silva', '48973215', '1995-03-10', 'LIC8899');
INSERT INTO Chofer VALUES (7, 'Diego', 'Suarez', '46239875', '1984-12-02', 'LIC6789');

-- Habilitaciones
INSERT INTO Habilitacion VALUES (1, 'Carga pesada');
INSERT INTO Habilitacion VALUES (2, 'Internacional');
INSERT INTO Habilitacion VALUES (3, 'Carga peligrosa');
INSERT INTO Habilitacion VALUES (4, 'Refrigerados');
INSERT INTO Habilitacion VALUES (5, 'Animales vivos');
INSERT INTO Habilitacion VALUES (6, 'Paqueter�a liviana');

-- Clientes
INSERT INTO Cliente VALUES (1, 'Rivera', 123, 'Translog S.A.', 'Uruguay');
INSERT INTO Cliente VALUES (2, 'Brasil', 45, 'Exportar SRL', 'Argentina');
INSERT INTO Cliente VALUES (3, 'Brasil', 67, 'Ejemplo3 SRL', 'Peru');
INSERT INTO Cliente VALUES (4, 'Brasil', 34, 'Ejemplo4 SRL', 'Francia');
INSERT INTO Cliente VALUES (5, 'Uruguay', 89, 'Logistic Max SA', 'Chile');
INSERT INTO Cliente VALUES (6, 'Argentina', 12, 'Transporte Total SRL', 'Brasil');
INSERT INTO Cliente VALUES (7, 'Orinoco', 3210, 'Distribuidora Alfa', 'Uruguay');
INSERT INTO Cliente VALUES (8, 'Av. Italia', 7654, 'Translatam Cargo', 'Paraguay');
INSERT INTO Cliente VALUES (9, 'Mill�n', 3025, 'Sudamericana Freight', 'Uruguay');
INSERT INTO Cliente VALUES (10, 'General Paz', 410, 'Patria Logistics', 'Argentina');


-- Tipo de Veh�culo
INSERT INTO TipoVehiculo VALUES ('CAM12', 'Cami�n mediano');
INSERT INTO TipoVehiculo VALUES ('FUR34', 'Furg�n liviano');
INSERT INTO TipoVehiculo VALUES ('CAM55', 'Cami�n liviano');
INSERT INTO TipoVehiculo VALUES ('CAM77', 'Cami�n pesado');
INSERT INTO TipoVehiculo VALUES ('FUR66', 'Furg�n refrigerado');
INSERT INTO TipoVehiculo VALUES ('VAN88', 'Mini van');


-- Veh�culos
INSERT INTO Vehiculo VALUES (1, 'Volvo', 'ABC1234', 'FH16', 2.5, 10000, 2018, 'Cami�n de gran porte', 'CAM12');
INSERT INTO Vehiculo VALUES (2, 'Peugeot', 'BCD5678', 'Partner', 1.1, 2000, 2020, 'Furg�n peque�o', 'FUR34');
INSERT INTO Vehiculo VALUES (3, 'Mercedes-Benz', 'CDE7890', 'Actros', 3.0, 12000, 2019, 'Cami�n de carga', 'CAM77');
INSERT INTO Vehiculo VALUES (4, 'Iveco', 'DEF3456', 'Eurocargo', 2.0, 8500, 2021, 'Cami�n mediano', 'CAM12');
INSERT INTO Vehiculo VALUES (5, 'Renault', 'EFG9876', 'Kangoo', 1.0, 1800, 2022, 'Veh�culo urbano', 'FUR66');
INSERT INTO Vehiculo VALUES (6, 'Toyota', 'FGH1234', 'Hiace', 1.2, 2200, 2023, 'Van log�stica', 'VAN88');
INSERT INTO Vehiculo VALUES (7, 'Scania', 'GHI4567', 'R500', 3.2, 14000, 2020, 'Cami�n de transporte pesado', 'CAM77');
INSERT INTO Vehiculo VALUES (8, 'Ford', 'HIJ8901', 'Transit', 1.3, 2500, 2023, 'Furg�n mediano para reparto', 'FUR34');


-- Insumos
INSERT INTO Insumo VALUES ('CAJAA', 'Caja cart�n', 500, 'Empaques SA', NULL);
INSERT INTO Insumo VALUES ('FILMM', 'Film pl�stico', 300, 'Empaques SA', 'CAJAA');
INSERT INTO Insumo VALUES ('ESPON', 'Esponja protecci�n', 150, 'Protec SRL', NULL);
INSERT INTO Insumo VALUES ('CINTA', 'Cinta adhesiva', 400, 'Empaques SA', 'CAJAA');
INSERT INTO Insumo VALUES ('BOLSA', 'Bolsa burbuja', 250, 'Protec SRL', NULL);
INSERT INTO Insumo VALUES ('ETIQR', 'Etiqueta RFID', 80, 'SmartLog SA', NULL);
INSERT INTO Insumo VALUES ('CONF1', 'Plastico', 80, 'SmartLog SA', 'CAJAA');

-- Env�os
INSERT INTO Envio VALUES (1, '2025-11-01 08:00', '2025-11-01 18:00', NULL, 1);
INSERT INTO Envio VALUES (2, '2025-11-02 09:00', '2025-11-02 15:00', NULL, 2);
INSERT INTO Envio VALUES (3, '2025-11-03 07:30', '2025-11-03 16:00', NULL, 3);
INSERT INTO Envio VALUES (4, '2025-11-04 10:15', '2025-11-04 20:00', NULL, 4);
INSERT INTO Envio VALUES (5, '2025-11-05 06:50', '2025-11-05 13:00', NULL, 5);
INSERT INTO Envio VALUES (6, '2025-11-06 12:00', '2025-11-06 18:00', NULL, 6);
INSERT INTO Envio VALUES (7, '2025-11-06 08:15:00', '2025-11-06 15:30:00', NULL, 1);
INSERT INTO Envio VALUES (8, '2025-11-06 14:20:00', '2025-11-06 20:30:00', NULL, 2);
INSERT INTO Envio VALUES (9, '2025-11-07 07:50:00', '2025-11-07 17:15:00', NULL, 3);
INSERT INTO Envio VALUES (10, '2025-11-07 10:40:00', '2025-11-07 18:00:00', NULL, 4);
INSERT INTO Envio VALUES (11, '2025-11-08 06:10:00', '2025-11-08 13:50:00', NULL, 5);
INSERT INTO Envio VALUES (12, '2025-11-08 09:25:00', '2025-11-08 21:00:00', NULL, 6);
INSERT INTO Envio VALUES (13, '2025-11-09 07:10', '2025-11-09 15:30', '2025-11-09 15:20', 1);
INSERT INTO Envio VALUES (14, '2025-11-09 10:45', '2025-11-09 18:00', '2025-11-09 18:25', 2);
INSERT INTO Envio VALUES (15, '2025-11-10 06:30', '2025-11-10 13:00', '2025-11-10 12:40', 3);
INSERT INTO Envio VALUES (16, '2025-11-10 13:15', '2025-11-10 21:00', '2025-11-10 21:10', 4);
INSERT INTO Envio VALUES (17, '2025-11-11 08:00', '2025-11-11 14:30', '2025-11-11 14:10', 5);
INSERT INTO Envio VALUES (18, '2025-11-11 09:50', '2025-11-11 16:00', '2025-11-11 16:35', 6);
INSERT INTO Envio VALUES (19, '2025-11-12 07:25', '2025-11-12 15:40', '2025-11-12 15:55', 1);
INSERT INTO Envio VALUES (20, '2025-11-12 12:00', '2025-11-12 19:30', '2025-11-12 19:10', 2);
INSERT INTO Envio VALUES (21, '2025-11-13 06:40', '2025-11-13 14:00', '2025-11-13 13:50', 3);
INSERT INTO Envio VALUES (22, '2025-11-13 14:15', '2025-11-13 22:00', '2025-11-13 22:20', 4);
INSERT INTO Envio VALUES (23, '2025-11-14 08:05', '2025-11-14 15:00', '2025-11-14 14:55', 5);
INSERT INTO Envio VALUES (24, '2025-11-14 09:35', '2025-11-14 18:00', '2025-11-14 17:50', 6);
INSERT INTO Envio VALUES (25, '2025-11-13 08:00:00', '2025-11-13 18:00:00', '2025-11-13 18:05:00', 1);
INSERT INTO Envio VALUES (26, '2025-11-13 09:00:00', '2025-11-13 15:00:00', '2025-11-13 15:02:00', 2);
INSERT INTO Envio VALUES (27, '2025-11-14 08:00:00', '2025-11-14 18:00:00', '2025-11-14 18:07:00', 1);
INSERT INTO Envio VALUES (28, '2025-11-14 09:00:00', '2025-11-14 15:00:00', '2025-11-14 15:03:00', 6);
INSERT INTO Envio VALUES (29, '2025-11-15 08:00:00', '2025-11-15 18:00:00', '2025-11-15 18:05:00', 1);
INSERT INTO Envio VALUES (30, '2025-11-15 09:00:00', '2025-11-15 15:00:00', '2025-11-15 15:06:00', 5);
INSERT INTO Envio VALUES (31, '2025-11-16 08:00:00', '2025-11-16 18:00:00', '2025-11-16 18:02:00', 1);
INSERT INTO Envio VALUES (32, '2025-11-16 09:00:00', '2025-11-16 15:00:00', '2025-11-16 15:05:00', 2);
INSERT INTO Envio VALUES (33, '2025-11-17 08:00:00', '2025-11-17 18:00:00', '2025-11-17 18:10:00', 1);
INSERT INTO Envio VALUES (34, '2025-11-17 09:00:00', '2025-11-17 15:00:00', '2025-11-17 15:01:00', 3);
INSERT INTO Envio VALUES (35, '2025-11-18 08:00:00', '2025-11-18 18:00:00', '2025-11-18 18:06:00', 1);
INSERT INTO Envio VALUES (36, '2025-11-18 09:00:00', '2025-11-18 15:00:00', '2025-11-18 15:03:00', 4);
INSERT INTO Envio VALUES (37, '2025-11-19 08:00:00', '2025-11-19 18:00:00', '2025-11-19 18:08:00', 1);
INSERT INTO Envio VALUES (38, '2025-11-19 09:00:00', '2025-11-19 15:00:00', '2025-11-19 15:02:00', 5);
INSERT INTO Envio VALUES (39, '2025-11-20 08:00:00', '2025-11-20 18:00:00', '2025-11-20 18:04:00', 1);
INSERT INTO Envio VALUES (40, '2025-11-20 09:00:00', '2025-11-20 15:00:00', '2025-11-20 15:07:00', 6);
INSERT INTO Envio VALUES (41, '2025-11-21 08:00:00', '2025-11-21 18:00:00', '2025-11-21 18:09:00', 1);
INSERT INTO Envio VALUES (42, '2025-11-21 09:00:00', '2025-11-21 15:00:00', '2025-11-21 15:03:00', 7);
INSERT INTO Envio VALUES (43, '2025-11-22 08:00:00', '2025-11-22 18:00:00', '2025-11-22 18:05:00', 1);
INSERT INTO Envio VALUES (44, '2025-11-22 09:00:00', '2025-11-22 15:00:00', '2025-11-22 15:01:00', 2);
INSERT INTO Envio VALUES (45, '2025-11-23 08:00:00', '2025-11-23 18:00:00', '2025-11-23 18:06:00', 1);
INSERT INTO Envio VALUES (46, '2025-11-23 09:00:00', '2025-11-23 15:00:00', '2025-11-23 15:04:00', 3);
INSERT INTO Envio VALUES (47, '2025-11-24 08:00:00', '2025-11-24 18:00:00', '2025-11-24 18:02:00', 1);
INSERT INTO Envio VALUES (48, '2025-11-24 09:00:00', '2025-11-24 15:00:00', '2025-11-24 15:05:00', 4);
INSERT INTO Envio VALUES (49, '2025-11-25 08:00:00', '2025-11-25 18:00:00', '2025-11-25 18:03:00', 1);
INSERT INTO Envio VALUES (50, '2025-11-25 09:00:00', '2025-11-25 15:00:00', '2025-11-25 15:07:00', 5);
INSERT INTO Envio VALUES (51, '2025-11-26 08:00:00', '2025-11-26 18:00:00', '2025-11-26 18:08:00', 1);
INSERT INTO Envio VALUES (52, '2025-11-26 09:00:00', '2025-11-26 15:00:00', '2025-11-26 15:02:00', 2);
INSERT INTO Envio VALUES (53, '2025-11-27 08:00:00', '2025-11-27 18:00:00', '2025-11-27 18:05:00', 1);
INSERT INTO Envio VALUES (54, '2025-11-27 09:00:00', '2025-11-27 15:00:00', '2025-11-27 15:03:00', 6);
INSERT INTO Envio VALUES (55, '2025-11-28 08:00:00', '2025-11-28 18:00:00', '2025-11-28 18:09:00', 1);
INSERT INTO Envio VALUES (56, '2025-11-28 09:00:00', '2025-11-28 15:00:00', '2025-11-28 15:01:00', 2);
INSERT INTO Envio VALUES (57, '2025-11-29 08:00:00', '2025-11-29 18:00:00', '2025-11-29 18:04:00', 1);
INSERT INTO Envio VALUES (58, '2025-11-29 09:00:00', '2025-11-29 15:00:00', '2025-11-29 15:06:00', 3);
INSERT INTO Envio VALUES (59, '2025-11-30 08:00:00', '2025-11-30 18:00:00', '2025-11-30 18:02:00', 1);
INSERT INTO Envio VALUES (60, '2025-11-30 09:00:00', '2025-11-30 15:00:00', '2025-11-30 15:05:00', 4);

-- Paquetes
INSERT INTO Paquete VALUES (1, 'Paquete liviano', 0.8, 10.0, 1, 1);
INSERT INTO Paquete VALUES (2, 'Paquete pesado', 1.5, 50.0, 2, 1);
INSERT INTO Paquete VALUES (3, 'Cajas de repuestos', 2.0, 80.0, 3, 2);
INSERT INTO Paquete VALUES (4, 'Material fr�gil', 1.2, 25.0, 4, 3);
INSERT INTO Paquete VALUES (5, 'Perecederos refrigerados', 2.5, 60.0, 5, 4);
INSERT INTO Paquete VALUES (6, 'Carga en pallets', 3.5, 130.0, 6, 5);
INSERT INTO Paquete VALUES (7, 'Documentaci�n corporativa', 0.3, 5.0, 1, 2);
INSERT INTO Paquete VALUES (8, 'Electr�nica peque�a', 0.8, 12.0, 1, 3);
INSERT INTO Paquete VALUES (9, 'Alimentos secos', 1.2, 20.0, 1, 5);
INSERT INTO Paquete VALUES (10, 'Partes mec�nicas', 2.0, 55.0, 2, 4);
INSERT INTO Paquete VALUES (11, 'Muestras comerciales', 0.6, 8.0, 2, 5);
INSERT INTO Paquete VALUES (12, 'Repuestos automotrices', 3.0, 95.0, 4, 7);
INSERT INTO Paquete VALUES (13, 'Indumentaria', 1.0, 18.0, 4, 9);
INSERT INTO Paquete VALUES (14, 'Papeler�a corporativa', 0.5, 7.0, 4, 12);
INSERT INTO Paquete VALUES (15, 'Productos farmac�uticos', 1.1, 15.0, 5, 11);
INSERT INTO Paquete VALUES (16, 'Alimentos refrigerados', 2.4, 58.0, 5, 13);

-- Tel�fonos
INSERT INTO TelefonoChofer VALUES (1, '099123456');
INSERT INTO TelefonoChofer VALUES (2, '091654321');
INSERT INTO TelefonoChofer VALUES (3, '098777444');
INSERT INTO TelefonoChofer VALUES (4, '094556677');
INSERT INTO TelefonoChofer VALUES (5, '097334455');
INSERT INTO TelefonoChofer VALUES (6, '093221100');

INSERT INTO TelefonoCliente VALUES (1, '29011234');
INSERT INTO TelefonoCliente VALUES (2, '43019876');
INSERT INTO TelefonoCliente VALUES (3, '51234590');
INSERT INTO TelefonoCliente VALUES (4, '40123456');
INSERT INTO TelefonoCliente VALUES (5, '44988765');
INSERT INTO TelefonoCliente VALUES (6, '55228765');

-- ChoferTieneHabilitacion
INSERT INTO ChoferTieneHabilitacion VALUES (1, 1);
INSERT INTO ChoferTieneHabilitacion VALUES (2, 2);
INSERT INTO ChoferTieneHabilitacion VALUES (3, 1);
INSERT INTO ChoferTieneHabilitacion VALUES (3, 3);
INSERT INTO ChoferTieneHabilitacion VALUES (4, 6);
INSERT INTO ChoferTieneHabilitacion VALUES (5, 4);
INSERT INTO ChoferTieneHabilitacion VALUES (6, 5);

--ChoferEnvioAsignado
INSERT INTO ChoferEnvioAsignado VALUES (1, 1);
INSERT INTO ChoferEnvioAsignado VALUES (2, 2);
INSERT INTO ChoferEnvioAsignado VALUES (3, 3);
INSERT INTO ChoferEnvioAsignado VALUES (4, 4);
INSERT INTO ChoferEnvioAsignado VALUES (5, 5);
INSERT INTO ChoferEnvioAsignado VALUES (6, 6);

-- Paquete requiere insumos
INSERT INTO PaqueteRequiereInsumos VALUES (1, 'CAJAA');
INSERT INTO PaqueteRequiereInsumos VALUES (2, 'FILMM');
INSERT INTO PaqueteRequiereInsumos VALUES (3, 'BOLSA');
INSERT INTO PaqueteRequiereInsumos VALUES (4, 'BOLSA');
INSERT INTO PaqueteRequiereInsumos VALUES (5, 'CAJAA');
INSERT INTO PaqueteRequiereInsumos VALUES (6, 'ETIQR');

-- RegistroDeEvento
INSERT INTO RegistroDeEvento VALUES (1, 1, '2025-11-01', '08:00', 'Salida desde planta');
INSERT INTO RegistroDeEvento VALUES (1, 2, '2025-11-01', '14:00', 'Llegada a destino');
INSERT INTO RegistroDeEvento VALUES (2, 1, '2025-11-02', '09:00', 'Salida desde planta');
INSERT INTO RegistroDeEvento VALUES (3, 1, '2025-11-03', '07:30', 'Salida desde planta');
INSERT INTO RegistroDeEvento VALUES (4, 1, '2025-11-04', '10:15', 'Salida desde planta');
INSERT INTO RegistroDeEvento VALUES (5, 1, '2025-11-05', '06:50', 'Salida desde planta');