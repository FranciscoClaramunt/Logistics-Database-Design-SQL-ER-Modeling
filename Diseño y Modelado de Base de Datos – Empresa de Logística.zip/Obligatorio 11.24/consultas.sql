
--DQL
-- Use obligatorio
--Insert
-- 4 Resolver las consultas

--5.1 Listar cada cliente con la cantidad total de env�os que ha realizado.

SELECT 
    c.numeroCliente,
    c.RazonSocial,
    COUNT(DISTINCT e.NumeroEnvio) AS CantidadEnvios
FROM Cliente c
JOIN Paquete p ON p.numeroCliente = c.numeroCliente
JOIN Envio e ON p.NumeroEnvio = e.NumeroEnvio
GROUP BY c.numeroCliente, c.RazonSocial;


--5.2 Mostrar todos los clientes y la cantidad de env�os.

SELECT
    c.numeroCliente,
    c.RazonSocial,
    (
        SELECT COUNT(*)
        FROM Paquete p
        WHERE p.numeroCliente = c.numeroCliente
    ) AS CantidadEnvios
FROM Cliente c;


--5.3 Calcular el peso promedio de los paquetes transportados por cada veh�culo.

SELECT 
    v.IdVehiculo,
    v.Marca,
    v.Modelo,
    AVG(p.Peso) AS PesoPromedio
FROM Vehiculo v
JOIN Envio e
    ON e.IdVehiculo = v.IdVehiculo
JOIN Paquete p
    ON p.NumeroEnvio = e.NumeroEnvio
GROUP BY v.IdVehiculo, v.Marca, v.Modelo
ORDER BY v.IdVehiculo;


--5.4 Listar los choferes que existen en la empresa pero que nunca participaron en ning�n env�o.

SELECT 
    c.numeroFuncionario,
    c.Nombre,
    c.Apellido
FROM Chofer c
WHERE c.numeroFuncionario NOT IN (
    SELECT numeroFuncionario FROM ChoferEnvioAsignado
);

--5.5 Obtener el veh�culo con mayor cantidad de env�os realizados.

select IdVehiculo,count(*) as TotalDeEnvios from Envio
group by IdVehiculo
having count(*) >=all(select count(*) as TotalDeEnvios from Envio
group by IdVehiculo);

--5.6 Listar cada insumo junto con la descripci�n de los insumos que son compatibles con �l.

select a.CodigoInsumo, a.Descripcion,
(select b.Descripcion from Insumo b 
where a.CodigoInsumoReemplazo = b.CodigoInsumo) as InsumoCompatible
from Insumo a

--5.7 Modificar la tabla de Insumos para agregar el stock disponible e inicializar este con el valor
--100 para todos los insumos existentes

--alter table Insumo
--add int Stock null;
update Insumo
set Stock = 100;
