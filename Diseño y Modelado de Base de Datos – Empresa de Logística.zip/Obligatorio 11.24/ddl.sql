--DDL

CREATE DATABASE Obligatorio_SQL
USE Obligatorio_SQL
set dateformat ymd


create table Chofer (
    numeroFuncionario int not null,
    Nombre varchar(30),
    Apellido varchar(30),
    CI varchar(12),
    FechaNacimiento datetime,
    NumeroLicencia varchar(20),
    primary key (numeroFuncionario)
);

create table Habilitacion (
    IdHabilitacion int not null,
    Descripcion varchar(20),
    primary key (IdHabilitacion)
);

create table Cliente (
    numeroCliente int not null,
    Calle varchar(20) not null,
    NroPuerta int not null,
    RazonSocial varchar(40) not null,
    Pais varchar(20) not null,
    primary key (numeroCliente)
);

create table TipoVehiculo (
    CodigoTipoVehiculo varchar(5) not null,
    Descripcion varchar(30) not null,
    primary key (CodigoTipoVehiculo)
);

create table Vehiculo (
    IdVehiculo int not null,
    Marca varchar(20) not null,
    Matricula varchar(15),
    Modelo varchar(20) not null,
    ConsumoPromedioPorKm decimal(6,2),
    Capacidad int CHECK (Capacidad >= 0),
    Anio int,
    Descripcion varchar(30) not null,
    CodigoTipoVehiculo varchar(5) not null,
    primary key (IdVehiculo),
    foreign key (CodigoTipoVehiculo) references TipoVehiculo(CodigoTipoVehiculo)
);

create table Insumo (
    CodigoInsumo varchar(5) not null,
    Descripcion varchar(20),
    Stock INT NOT NULL CHECK (Stock >= 0),
    Proveedor varchar(50),
    CodigoInsumoReemplazo varchar(5),
    primary key (CodigoInsumo),
    foreign key (CodigoInsumoReemplazo) references Insumo(CodigoInsumo)
);

create table Envio (
    NumeroEnvio int not null,
    FechaHoraSalida datetime,
    FechaHoraFinEst datetime,
    FechaHoraFinReal datetime,
    IdVehiculo int not null,
    primary key (NumeroEnvio),
    foreign key (IdVehiculo) references Vehiculo(IdVehiculo)
);

create table Paquete (
    IdPaquete int not null,
    Descripcion varchar(60) not null,
    Volumen decimal(10,2) CHECK (Volumen >= 0),
    Peso decimal(10,2) CHECK (Peso >= 0),
    numeroCliente int not null,
    NumeroEnvio int not null,
    primary key (IdPaquete),
    foreign key (numeroCliente) references Cliente(numeroCliente),
    foreign key (NumeroEnvio) references Envio(NumeroEnvio)
);

create table TelefonoChofer (
    numeroFuncionario int not null,
    Telefono varchar(20) not null,
    primary key (numeroFuncionario, Telefono),
    foreign key (numeroFuncionario) references Chofer(numeroFuncionario)
);

create table TelefonoCliente (
    numeroCliente int not null,
    Telefono varchar(20) not null,
    primary key (numeroCliente, Telefono),
    foreign key (numeroCliente) references Cliente(numeroCliente)
);

create table ChoferTieneHabilitacion (
    numeroFuncionario int not null,
    IdHabilitacion int not null,
    primary key (numeroFuncionario, IdHabilitacion),
    foreign key (numeroFuncionario) references Chofer(numeroFuncionario),
    foreign key (IdHabilitacion) references Habilitacion(IdHabilitacion)
);

create table ChoferEnvioAsignado (
    numeroFuncionario int not null,
    NumeroEnvio int not null,
    primary key (numeroFuncionario, NumeroEnvio),
    foreign key (numeroFuncionario) references Chofer(numeroFuncionario),
    foreign key (NumeroEnvio) references Envio(NumeroEnvio)
);

create table PaqueteRequiereInsumos (
    IdPaquete int not null,
    CodigoInsumo varchar(5) not null,
    primary key (IdPaquete, CodigoInsumo),
    foreign key (IdPaquete) references Paquete(IdPaquete),
    foreign key (CodigoInsumo) references Insumo(CodigoInsumo)
);

create table RegistroDeEvento (
    NumeroEnvio int not null,
    NumeroLinea int not null,
    Fecha datetime,
    Hora time,
    Descripcion varchar(100),
    primary key (NumeroEnvio, NumeroLinea),
    foreign key (NumeroEnvio) references Envio(NumeroEnvio)
);

